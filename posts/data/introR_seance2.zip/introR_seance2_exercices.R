# =============================================================================#
#         Exploration du jeu de données sur les lieux de tournage à Paris
#
#
# données et méta ici :
# https://opendata.paris.fr/explore/dataset/lieux-de-tournage-a-paris/information/?disjunctive.type_tournage&disjunctive.nom_tournage&disjunctive.nom_realisateur&disjunctive.nom_producteur&disjunctive.ardt_lieu&basemap=jawg.dark&location=11,48.84663,2.366
#
# jeu téléchargé le 2 décembre 2022
#
# JB, LC, AD
# décembre 2022
# =============================================================================#


# librairies
# tidyverse 
#Au fil du script : pensez à verifier que toutes les libraries dont vous avez besoin sont chargées 
library(readr)
library(stringr)
library(lubridate)
library(tidyr)
library(ggplot2)

#autre
library(skimr)


# 
sessionInfo()


# Import de données ----

# Lecture de table avec readr
data <- read_csv2("data/lieux-de-tournage-a-paris.csv")

# 
data <- read_csv2("data/lieux-de-tournage-a-paris.csv", 
                  col_types = cols(`Code postal` = col_character()),
                  show_col_types = TRUE)

# 
head(data)



# Manipuler des données ----

# ~1. Nettoyage : rename, select ----

# 
names(data)

# Création d'un nouvel objet lieuxTournage : les données sans info spatiales 
#Les infos spatiales sont contenues dans les colonnes "Coordonnée en X", "Coordonnée en Y", "geo_shape", "geo_point_2d"



#
names(lieuxTournage)

# 
newName <- c("ID", "ANNEE", "TYPE", "TITRE", "REAL", "PROD", 
              "ADRESSE", "CODE", "DATE_DEB", "DATE_FIN")

# Remplacer lieuxTournage par le même tableau dans lequel on renomme toutes les variables à l'aide de newName


# 
rm(newName)

# Afficher un aperçu de la table


# Un p'tit résumé du contenu 
skim(lieuxTournage)

# Modalités uniques des types de tournage
unique(lieuxTournage$TYPE)

# Transformer les types de tournage de la colonne TYPE en facteur 


# En deux lignes de codes indiquer combien et quelles sont les modalités possibles des types de tournage 


# 
sort(unique(lieuxTournage$CODE))

# Recodage de 75116 en 75016 et suppression de ce qui est hors de Paris


# 
sort(unique(lieuxTournage$CODE))


# Avec stringr : nettoyage des chaînes de caractères
# Titre, Réal et Prod 

# 
head(unique(lieuxTournage$REAL), 20)

# Harmoniser la formalisation des noms propres 
#Pour la colonne TITRE --> passer les titres en miniscule ?str_to_lower 
#Pour la colonne REAL --> mettez une majuscule au Nom et Prénom et le reste en miniscule ?str_to_title
#Pour la colonne PROD --> mettez tout en majuscule ?str_to_upper 


# ~2. Interroger/extraire : filter, select ----

# Sans créer d'objet, sélectionner les lieux de tournage et leur adresse


# Sans créer d'objet, sélectionner les lieux de tournage et les dates de début et de fin


# Sans créer d'objet, filtrer les lieux de tournage dans le 16e arrondissement 


# Sans créer d'objet, filtrer les lieux de tournage après 2017


# Sans créer d'objet, filtrer les lieux de tournage dans le 2e arrondissement et de 2016


# Sans créer d'objet, filtrer tous les lieux de tournage dont la production contient le nom GAUMONT


# Sans créer d'objet, filtrer tous les lieux de tournage où la réalisatrice s'appelle "Alexandra"


# Sans créer d'objet, filtrer tous les lieux de tournage de la série "arsene lupin"


# 
lieuxTournage %>% 
  filter(TYPE == "Long métrage") %>% 
  nrow()

## Suivre les différentes étapes pour répondre : Quelle est la part des longs métrages parmi l'ensemble des tournages ?
## stocker le nombre de tournage dans un objet n_tot


## stocker le nombre de tournage de type long métrage dans un objet n_lm 

## 
(n_lm / n_tot) * 100

## optionnel : effacer les valeurs n_tot et n_lm stockées si on en n'a plus besoin



# Bonus : sans créer d'objet, description stat sur la taille des titres oeuvres cinématographique
# Aide : Il est nécessaire de créer une nouvelle colonne TAILLE pour compter la taille des titres ?str_length




# ~3. Ajouter de l'info à sa table : mutate ----

# Les dates avec la librairie lubridate
class(lieuxTournage$DATE_DEB) 

# Calculer la durée des tournages dans une nouvelle variable DUREE que vous stockez dans le tableau lieuxTournage


# 
lieuxTournage <- lieuxTournage %>%
  mutate(JOUR_DEB = wday(DATE_DEB, label = FALSE),
         JOUR_FIN = wday(DATE_FIN, label = TRUE)) 

# Quel est le titre dont le tournage a duré le plus longtemps à Paris? 

  
# Combien de tournages ont duré plus de 20 jours ? 

  
# 
lieuxTournage <- lieuxTournage %>% 
  mutate(PERIODE = case_when(DATE_DEB < "2020-01-01" ~ "avant le covid",
                             DATE_DEB >= "2020-01-01" ~ "pendant le covid"))

table(lieuxTournage$PERIODE)

# ajout d'une variable TYPE_SIMPL au tableau lieuxTournage avec une condition : selon type de tournage



# 
lieuxTournage <- lieuxTournage %>% 
  group_by(TITRE) %>% 
  mutate(N_TOURNAGE = n()) %>% 
  ungroup() %>% 
  arrange(-N_TOURNAGE)



# ~4. Créer de l'info dans une nouvelle table : résumer avec group_by & summarise ----

# Dans un nouvel objet production calculez le nombre de lieux de tournage N_TOURNAGE par production (TITRE)
# reprise du code ci-dessus avec group_by + summarise



# Dans un nouvel objet arrondissement calculez le nombre de tournage N_TOURNAGE par arrondissement


# Dans un nouvel objet tournageByArrAnnee calculez le nombre de tournage N_TOURNAGE par arrondissement et par année


# Dans un nouvel objet tournageByArrType calculez le nombre de tournage N_TOURNAGE par type de production (film, série etc.) et par arrondissement


# Dans un nouvel objet tournageByArrTypePeriod calculez le nombre de tournage N_TOURNAGE par type de production (film, série etc.) par arrondissement et période


# Dans un nouvel objet tournageByTypeS calculez le nombre N_TOURNAGE et % de tournage PCT_TOURNAGE par type de production simplifié (TYPE_SIMPL)


# Quel est le type de production le moins représenté à Paris ? 


# Y-a-t-il une saisonnalité des tournages ? 
#
tournageByMonth <-lieuxTournage %>%
  mutate(MONTH = month(DATE_DEB)) %>%  # nouvelle variable MONTH
  group_by(MONTH) %>% 
  summarise(N_TOURNAGE = n()) %>% 
  mutate(PCT_TOURNAGE = (N_TOURNAGE/sum(N_TOURNAGE)*100)) %>% 
  arrange(PCT_TOURNAGE)

# Dans un nouvel objet tournageByArrPeriod , nombre N_TOURNAGE et % de tournage P_TOURNAGE par arrondissement et période



# ~5. Restructurer une table (tidyr) ----

## Passage au format large : en ligne les individus statistiques 
## décrits par des variables en colonne 

# Passer la table tournageByArrType (format long) au format large (où individu stat = code géo)
arrondissement1 <- tournageByArrType %>% 
  pivot_wider(names_from = TYPE,          # les modalités à transformer en variable
              values_from = N_TOURNAGE)   # les valeurs correspondantes à ces nouvelles variables

# Passer la table tournageByArrTypePeriod (format long) au format large
arrondissement2 <- tournageByArrTypePeriod %>% 
  pivot_wider(names_from = c(TYPE, PERIODE),  # on peut combiner les modalités de plusieurs variables
              values_from = N_TOURNAGE)

# Passer la table tournageByArrPeriod (format long) au format large
arrondissement3 <- tournageByArrPeriod %>% 
  pivot_wider(names_from = PERIODE,
              values_from = c(N_TOURNAGE, P_TOURNAGE))  # on peut combiner plusieurs info quantitatives 
               

# Bonus : à partir de arrondissement3, calculer un taux de variation dans une nouvelle variable
arrondissement3 <- arrondissement3 %>% 
  mutate(TXVAR = (`P_TOURNAGE_pendant le covid` - `P_TOURNAGE_avant le covid`) / `P_TOURNAGE_avant le covid`)


## Passage au format long 
tournageByArrPeriod2 <- arrondissement3 %>% 
  pivot_longer(cols = c(`P_TOURNAGE_pendant le covid`,`P_TOURNAGE_avant le covid`),
               names_to = "PERIODE",
               names_prefix = "P_TOURNAGE_",
               values_to = "P_TOURNAGE") %>% 
  select(CODE, PERIODE, P_TOURNAGE)


# ~6. Jointure de table ----

# on importe des données complémentaires au niveau des arrondissements
arrData <- read_csv2("data/arrondissements_data.csv")
arrData <- arrData %>% 
  mutate(CODE = as.character(CP))

# jointure de ces données complémentaires 
# avec le tableau du nombre de tournages par arrondissement
arrData <- arrondissement %>% 
  left_join(., arrData) %>% 
  select(-c(CP, CODGEO, LIBGEO))

# création d'une nouvelle variable :
# nombre de tournages pour 1000 habitants (cf. arrondissement_meta.xls)
arrData <- arrData %>% 
  mutate(N_TOURNAGE_kh = (N_TOURNAGE / P19_POP) * 1000)




# ~7. BONUS : visualiser avec ggplot2 ----


## arrData
# observation graphique de la relation entre le nombre de tournage 
# et le nombre de bâtiment historique, pour 1000 habitants
ggplot(arrData, aes(x = Nb_BatHist_kh, y = N_TOURNAGE_kh)) +
  geom_point()

# observation graphique de la relation entre le nombre de tournage 
# et le nombre d'hôtels, pour 1000 habitants
ggplot(arrData, aes(x = Ntot_Hotel_19_kh, y = N_TOURNAGE_kh)) +
  geom_point()

# observation graphique de la relation entre le nombre de tournage 
# et le nombre de vieux logements (construction avant 1919), pour 1000 habitants
ggplot(arrData, aes(x = P19_RP_ACH19_kh, y = N_TOURNAGE_kh)) +
  geom_point()



## lieuxTournage
# où la série Emily in Paris a-t-elle été le plus tournée ? réponse visuelle avec ggplot
ggplot(lieuxTournage %>% filter(TITRE == "emily in paris"), aes(x = CODE)) +
  geom_bar()

# à quelle année trouve-t-on le plus de tournage de film ? réponse visuelle avec ggplot
ggplot(lieuxTournage %>% filter(TYPE_SIMPL == "film"), aes(x = ANNEE)) +
  geom_bar()

# Quelle est la répartion des types de production par année ? réponse visuelle avec ggplot
ggplot(lieuxTournage, aes(x = ANNEE, fill = TYPE_SIMPL)) +
  geom_bar(position = "dodge")

# Visualiser les taux de variation par arrondissement
ggplot(arrondissement3, aes(x = CODE, y = TXVAR)) +
  geom_bar(stat = "identity") 

# Visualiser la table tournageByArrPeriod
ggplot(tournageByArrPeriod, aes(x = CODE, y = P_TOURNAGE, fill = PERIODE)) +
  geom_bar(stat = "identity", position = "dodge")

# Visualiser la table tournageByArrTypePeriod dans 4 graphiques (un graphique par type)
ggplot(tournageByArrTypePeriod, aes(x = CODE, y = N_TOURNAGE, fill = PERIODE)) +
  geom_bar(stat = "identity", position = "dodge") +
  facet_wrap(~TYPE)




# Export de données ----

# Au format csv2
write_csv2(x = lieuxTournage,
           file = "data/lieux_de_tournage_a_paris_clean.csv")

# Au format RDS
saveRDS(object = lieuxTournage,
        file = "data/lieux_de_tournage_a_paris_clean.rds")

# Ouvrir un fichier RDS
data <- readRDS(file = "data/lieux_de_tournage_a_paris_clean.rds")







