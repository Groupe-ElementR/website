# =============================================================================#
#         Exploration du jeu de données sur les lieux de tournage à Paris
#
#
# données et méta ici :
# https://opendata.paris.fr/explore/dataset/lieux-de-tournage-a-paris/information/?disjunctive.type_tournage&disjunctive.nom_tournage&disjunctive.nom_realisateur&disjunctive.nom_producteur&disjunctive.ardt_lieu&basemap=jawg.dark&location=11,48.84663,2.366
#
# jeu téléchargé le 2 décembre 2022
#
# JB, LC, AD
# décembre 2022
# =============================================================================#


# librairies
# tidyverse
library(readr)
library(dplyr)
library(stringr)
library(lubridate)
library(tidyr)
library(ggplot2)

#autre
library(skimr)


# afficher les versions utilisées
sessionInfo()


# Import de données ----

# Lecture de table avec readr
data <- read_csv2("data/lieux-de-tournage-a-paris.csv")

# Lecture de table avec readr en spécifiant le type de la colonne "Code postal"
data <- read_csv2("data/lieux-de-tournage-a-paris.csv", 
                  col_types = cols(`Code postal` = col_character()),
                  show_col_types = TRUE)

# afficher les 1ères lignes de la table
head(data)



# Manipuler des données ----

# ~1. Nettoyage : rename, select ----

# liste des variables des données brutes
names(data)

# Création d'un nouvel objet : les données sans info spatiales
lieuxTournage <- data %>% 
  select(-c("Coordonnée en X", "Coordonnée en Y", "geo_shape", "geo_point_2d"))

# liste des variables 
names(lieuxTournage)

# création d'un vecteur intermédiaire qui stocke les futurs noms
newName <- c("ID", "ANNEE", "TYPE", "TITRE", "REAL", "PROD", 
              "ADRESSE", "CODE", "DATE_DEB", "DATE_FIN")

# On renomme toutes les variables
lieuxTournage <- lieuxTournage %>% 
  rename_all(~newName)

# On supprime le vecteur intermédiaire
rm(newName)

# Afficher un aperçu de la table
head(lieuxTournage)

# Un p'tit résumé du contenu 
skim(lieuxTournage)

# Modalités uniques des types de tournage
unique(lieuxTournage$TYPE)

# Transfo des types de tournage en facteur
lieuxTournage <- lieuxTournage %>% 
  mutate(TYPE = as.factor(TYPE))

# Modalités possibles des types de tournage
nlevels(lieuxTournage$TYPE) # combien
levels(lieuxTournage$TYPE)  # lesquelles

# liste des codes géo
sort(unique(lieuxTournage$CODE))

# Recodage de 75116 en 75016 et suppression de ce qui est hors de Paris
lieuxTournage <- lieuxTournage %>% 
  mutate(CODE = recode(CODE, "75116" =  "75016")) %>% 
  filter(!CODE %in% c("92220", "93200", "93320", "93500", "94320") & !is.na(CODE))

# liste des codes géo
sort(unique(lieuxTournage$CODE))


# Avec stringr : nettoyage des chaînes de caractères
# Titre, Réal et Prod 

# Explorer les 20 premiers noms de réalisateurices
head(unique(lieuxTournage$REAL), 20)

# Harmoniser la formalisation des noms propres 
lieuxTournage <- lieuxTournage %>%
  mutate(TITRE = str_to_lower(TITRE), #?str_to_lower   
         REAL = str_to_title(REAL),   #?str_to_title
         PROD = str_to_upper(PROD))   #?str_to_upper  


# ~2. Interroger/extraire : filter, select ----

# Sans créer d'objet, sélectionner les lieux de tournage et leur adresse
lieuxTournage %>% 
  select(ID, ADRESSE)

# Sans créer d'objet, sélectionner les lieux de tournage et les dates de début et de fin
lieuxTournage %>% 
  select(ID, DATE_DEB, DATE_FIN)

# Sans créer d'objet, filtrer les lieux de tournage dans le 16e arrondissement 
lieuxTournage %>% 
  filter(CODE == "75016")

# Sans créer d'objet, filtrer les lieux de tournage après 2017
lieuxTournage %>% 
  filter(ANNEE > 2017)

# Sans créer d'objet, filtrer les lieux de tournage dans le 2e arrondissement et de 2016
lieuxTournage %>% 
  filter(CODE == "75002" & ANNEE == 2016)

# Sans créer d'objet, filtrer tous les lieux de tournage dont la production contient le nom GAUMONT
lieuxTournage %>% 
  filter(str_detect(PROD, "GAUMONT"))

# Sans créer d'objet, filtrer tous les lieux de tournage où la réalisatrice s'appelle "Alexandra"
lieuxTournage %>% 
  filter(str_detect(REAL, "Alexandra"))

# Sans créer d'objet, filtrer tous les lieux de tournage de la série "arsene lupin"
lieuxTournage %>% 
  filter(TITRE == "arsene lupin")


# Sans créer d'objet, combien de lieux de tournage pour les longs métrages ?
lieuxTournage %>% 
  filter(TYPE == "Long métrage") %>% 
  nrow()

## Quelle est la part des longs métrages parmi l'ensemble des tournages ?
## stocker le nombre de tournage dans un objet
n_tot <- lieuxTournage %>%
  nrow()

## stocker le nombre de tournage de type long métrage
n_lm <- lieuxTournage %>% 
  filter(TYPE == "Long métrage") %>% 
  nrow()

## calcul du %
(n_lm / n_tot) * 100

## optionnel : effacer les valeurs stockées si on en n'a plus besoin
rm(n_lm, n_tot)


# Bonus : sans créer d'objet, description stat sur la taille des titres 
lieuxTournage %>%
  mutate(TAILLE = str_length(TITRE)) %>% # ?str_length
  select(TAILLE) %>%                     # on ne garde qu'une colonne 
  summary()                              # on fait un résumé stat 




# ~3. Ajouter de l'info à sa table : mutate ----

# Les dates avec la librairie lubridate
class(lieuxTournage$DATE_DEB) 

# Calculer la durée des tournages dans une nouvelle variable
lieuxTournage <- lieuxTournage %>%
    mutate(DUREE = DATE_FIN - DATE_DEB + 1)

# Bonus : Ajouter le jour de la semaine correspondant aux dates
lieuxTournage <- lieuxTournage %>%
  mutate(JOUR_DEB = wday(DATE_DEB, label = FALSE),
         JOUR_FIN = wday(DATE_FIN, label = TRUE)) 

# Quel est le titre dont le tournage a duré le plus longtemps à Paris? 
lieuxTournage %>% 
  filter(DUREE == max(DUREE)) %>% 
  pull(TITRE)
  
# Combien de tournages ont durée plus de 20 jours ? 
lieuxTournage %>% 
  filter(DUREE>20) %>% 
  nrow()
  
# Ajout d'une variable avec une condition : selon date de tournage 
lieuxTournage <- lieuxTournage %>% 
  mutate(PERIODE = case_when(DATE_DEB < "2020-01-01" ~ "avant le covid",
                             DATE_DEB >= "2020-01-01" ~ "pendant le covid"))

table(lieuxTournage$PERIODE)

# ajout d'une variable avec une condition : selon type de tournage
lieuxTournage <- lieuxTournage %>% 
  mutate(TYPE_SIMPL = case_when(TYPE %in% c("Série TV", "Téléfilm")  ~ "tv",
                                TYPE == "Long métrage" ~ "film",
                                TRUE ~ "web"))


# Quelle production (TITRE) a le plus de tournages (en nombre de lieux de tournage) ?
# nombre de lieux de tournage par production : group_by + mutate
lieuxTournage <- lieuxTournage %>% 
  group_by(TITRE) %>% 
  mutate(N_TOURNAGE = n()) %>% 
  ungroup() %>% 
  arrange(-N_TOURNAGE)




# ~4. Créer de l'info dans une nouvelle table : résumer avec group_by & summarise ----

# Dans un nouvel objet "production", nombre de lieux de tournage par production (TITRE)
# reprise du code ci-dessus avec group_by + summarise
production <- lieuxTournage %>% 
  group_by(TITRE) %>% 
  summarise(N_TOURNAGE = n()) %>% 
  ungroup() %>% 
  arrange(-N_TOURNAGE)


# Dans un nouvel objet, nombre de tournage par arrondissement
arrondissement <- lieuxTournage %>% 
  group_by(CODE) %>% 
  summarise(N_TOURNAGE = n()) %>% 
  ungroup()

# Dans un nouvel objet, nombre de tournage par arrondissement et par année
tournageByArrAnnee <- lieuxTournage %>% 
  group_by(CODE, ANNEE) %>% 
  summarise(N_TOURNAGE = n()) %>% 
  ungroup()


# Dans un nouvel objet, nombre de tournage par type de production (film, série etc.) par arrondissement
tournageByArrType <- lieuxTournage %>% 
  group_by(CODE, TYPE) %>% 
  summarise(N_TOURNAGE = n()) %>% 
  ungroup()

# Dans un nouvel objet, nombre de tournage par type de production (film, série etc.) par arrondissement et période
tournageByArrTypePeriod <- lieuxTournage %>% 
  group_by(CODE, TYPE, PERIODE) %>% 
  summarise(N_TOURNAGE = n()) %>% 
  ungroup()


# Dans un nouvel objet, nombre et % de tournage par type de production simplifié (TYPE_SIMPL)
tournageByTypeS <- lieuxTournage %>%
  group_by(TYPE_SIMPL) %>% 
  summarise(N_TOURNAGE = n()) %>% 
  mutate(PCT_TOURNAGE = N_TOURNAGE/sum(N_TOURNAGE)*100)

# Quel est le type de production le moins représenté à Paris ? 
tournageByTypeS %>% 
  filter(PCT_TOURNAGE == min(PCT_TOURNAGE)) %>% 
  pull(TYPE_SIMPL)

# Y-a-t-il une saisonnalité des tournages ? 
# Dans un nouvel objet, nombre de tournages par mois
tournageByMonth <-lieuxTournage %>%
  mutate(MONTH = month(DATE_DEB)) %>%  # nouvelle variable MONTH
  group_by(MONTH) %>% 
  summarise(N_TOURNAGE = n()) %>% 
  mutate(PCT_TOURNAGE = (N_TOURNAGE/sum(N_TOURNAGE)*100)) %>% 
  arrange(PCT_TOURNAGE)

# Dans un nouvel objet, nombre et % de tournage par arrondissement et période
tournageByArrPeriod <- lieuxTournage %>% 
  group_by(CODE, PERIODE) %>% 
  summarise(N_TOURNAGE = n()) %>% 
  group_by(CODE) %>% 
  mutate(P_TOURNAGE = (N_TOURNAGE / sum(N_TOURNAGE)) * 100)


# ~5. Restructurer une table (tidyr) ----

## Passage au format large : en ligne les individus statistiques 
## décrits par des variables en colonne 

# Passer la table tournageByArrType (format long) au format large (où individu stat = code géo)
arrondissement1 <- tournageByArrType %>% 
  pivot_wider(names_from = TYPE,          # les modalités à transformer en variable
              values_from = N_TOURNAGE)   # les valeurs correspondantes à ces nouvelles variables

# Passer la table tournageByArrTypePeriod (format long) au format large
arrondissement2 <- tournageByArrTypePeriod %>% 
  pivot_wider(names_from = c(TYPE, PERIODE),  # on peut combiner les modalités de plusieurs variables
              values_from = N_TOURNAGE)

# Passer la table tournageByArrPeriod (format long) au format large
arrondissement3 <- tournageByArrPeriod %>% 
  pivot_wider(names_from = PERIODE,
              values_from = c(N_TOURNAGE, P_TOURNAGE))  # on peut combiner plusieurs info quantitatives 
               

# Bonus : à partir de arrondissement3, calculer un taux de variation dans une nouvelle variable
arrondissement3 <- arrondissement3 %>% 
  mutate(TXVAR = (`P_TOURNAGE_pendant le covid` - `P_TOURNAGE_avant le covid`) / `P_TOURNAGE_avant le covid`)


## Passage au format long 
tournageByArrPeriod2 <- arrondissement3 %>% 
  pivot_longer(cols = c(`P_TOURNAGE_pendant le covid`,`P_TOURNAGE_avant le covid`),
               names_to = "PERIODE",
               names_prefix = "P_TOURNAGE_",
               values_to = "P_TOURNAGE") %>% 
  select(CODE, PERIODE, P_TOURNAGE)


# ~6. Jointure de table ----

# on importe des données complémentaires au niveau des arrondissements
arrData <- read_csv2("data/arrondissements_data.csv")
arrData <- arrData %>% 
  mutate(CODE = as.character(CP))

# jointure de ces données complémentaires 
#avec le tableau du nombre de tournages par arrondissement
arrData <- arrondissement %>% 
  left_join(., arrData) %>% 
  select(-c(CP, CODGEO, LIBGEO))

# création d'une nouvelle variable :
# nombre de tournages pour 1000 habitants (cf. arrondissement_meta.xls)
arrData <- arrData %>% 
  mutate(N_TOURNAGE_kh = (N_TOURNAGE / P19_POP) * 1000)




# ~7. BONUS : visualiser avec ggplot2 ----


## arrData
# observation graphique de la relation entre le nombre de tournage 
# et le nombre de bâtiment historique, pour 1000 habitants
ggplot(arrData, aes(x = Nb_BatHist_kh, y = N_TOURNAGE_kh)) +
  geom_point()

# observation graphique de la relation entre le nombre de tournage 
# et le nombre d'hôtels, pour 1000 habitants
ggplot(arrData, aes(x = Ntot_Hotel_19_kh, y = N_TOURNAGE_kh)) +
  geom_point()

# observation graphique de la relation entre le nombre de tournage 
# et le nombre de vieux logements (construction avant 1919), pour 1000 habitants
ggplot(arrData, aes(x = P19_RP_ACH19_kh, y = N_TOURNAGE_kh)) +
  geom_point()




## lieuxTournage
# où la série Emily in Paris a-t-elle été le plus tournée ? réponse visuelle avec ggplot
ggplot(lieuxTournage %>% filter(TITRE == "emily in paris"), aes(x = CODE)) +
  geom_bar()

# à quelle année trouve-t-on le plus de tournage de film ? réponse visuelle avec ggplot
ggplot(lieuxTournage %>% filter(TYPE_SIMPL == "film"), aes(x = ANNEE)) +
  geom_bar()

# Quelle est la répartion des types de production par année ? réponse visuelle avec ggplot
ggplot(lieuxTournage, aes(x = ANNEE, fill = TYPE_SIMPL)) +
  geom_bar(position = "dodge")

# Visualiser les taux de variation par arrondissement
ggplot(arrondissement3, aes(x = CODE, y = TXVAR)) +
  geom_bar(stat = "identity") 

# Visualiser la table tournageByArrPeriod
ggplot(tournageByArrPeriod, aes(x = CODE, y = P_TOURNAGE, fill = PERIODE)) +
  geom_bar(stat = "identity", position = "dodge")

# Visualiser la table tournageByArrTypePeriod dans 4 graphiques (un graphique par type)
ggplot(tournageByArrTypePeriod, aes(x = CODE, y = N_TOURNAGE, fill = PERIODE)) +
  geom_bar(stat = "identity", position = "dodge") +
  facet_wrap(~TYPE)




# Export de données ----

# Au format csv2
write_csv2(x = lieuxTournage,
           file = "data/lieux_de_tournage_a_paris_clean.csv")

# Au format RDS
saveRDS(object = lieuxTournage,
        file = "data/lieux_de_tournage_a_paris_clean.rds")

# Ouvrir un fichier RDS
data <- readRDS(file = "data/lieux_de_tournage_a_paris_clean.rds")







