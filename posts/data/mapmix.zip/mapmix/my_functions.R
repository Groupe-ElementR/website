library(mapsf)
library(sf)

citymix <- function(x, y, n){
  # import des couches
  countries <- st_read("data/geocity.gpkg", "countries", quiet = TRUE)
  cities <-  st_read("data/geocity.gpkg", "cities", quiet = TRUE)

  # polygon layer & focus
  country <- countries[countries$ISO3_CODE == x, ]
  focus <- continental_country(country)

  # order and select cities
  cities <- cities[order(cities$POP, decreasing = TRUE), ]
  cities_x <- cities[cities$ISO3_CODE == x, ]
  cities_y <- cities[cities$ISO3_CODE == y, ]

  # compute the minimum number of cities
  n_villes <- min(nrow(cities_x), nrow(cities_y), n)
  cities_x <- cities_x[1:n_villes, ]
  cities_y <- cities_y[1:n_villes, ]

  # assign population and names from cities to cities
  cities_x$POP <- cities_y$POP
  cities_x$NAME <- cities_y$NAME

  # project layers using a local projection
  prj <- tmap:::to_generic_projected(focus, return_as = "wkt")
  cities_x <- st_transform(x = cities_x, prj)
  focus <- st_transform(x = focus, prj)
  country <- st_transform(x = country, prj)
  countries <- st_transform(x = countries[st_is_within_distance(x = countries,
                                                                y = country,
                                                                dist = 2000000,
                                                                sparse = FALSE), ],
                            crs = prj)

  # display the map
  mf_theme(x = "base", foreground = "#f2efe9", highlight = "#977ea2",
           mar = rep(.5, 4))
  mf_map(countries, lwd = 1.5, bg = "lightblue", extent = focus)
  mf_shadow(country, add = TRUE)
  mf_map(country, col = "#bddab1", add = TRUE)
  mf_map(cities_x, "POP", "prop", inches = .5, lwd = 1.2, leg_pos = NA)
  cex <- rep(0.8, n_villes)
  cex[1:3] <- c(1.5, 1.2, 1.2)
  mf_label(cities_x, var = "NAME", col = "gray5", overlap = FALSE, halo = TRUE,
           cex = cex, lines = FALSE, q = 3, pos = 3)
}

continental_country <- function(x){
  if(x$ISO3_CODE %in% c("FRA", "USA", "PRT", "ESP", "CHL", "ZAF", "RUS", "NZL")){
    i <- 1
    if (x$ISO3_CODE == "FRA"){
      i <- c(1, 3)
    }
    if (x$ISO3_CODE == "NZL"){
      i <- 1:3
    }
    x <- st_cast(st_geometry(x), "POLYGON")
    x <- x[order(st_area(x), decreasing = TRUE)]
    x <- x[i]
    x <- st_sf(x)
  }
  return(x)
}
