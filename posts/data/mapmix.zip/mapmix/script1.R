library(mapsf)
library(sf)
# import des couches
# countries from GISCO
# cities from natural earh
countries <- st_read("data/geocity.gpkg", "countries", quiet = TRUE)
cities <-  st_read("data/geocity.gpkg", "cities", quiet = TRUE)

# order and select cities in France and in Algeria
cities <- cities[order(cities$POP, decreasing = TRUE), ]
cities_DZA <- cities[cities$ISO3_CODE == "DZA", ]
cities_FRA <- cities[cities$ISO3_CODE == "FRA", ]

# compute the minimum number of cities
n_villes <- min(nrow(cities_DZA), nrow(cities_FRA), 25)
cities_DZA <- cities_DZA[1:n_villes, ]
cities_FRA <- cities_FRA[1:n_villes, ]

# assign population and names from alegrian cities to french cities
cities_FRA$POP <- cities_DZA$POP
cities_FRA$NAME <- cities_DZA$NAME

# manage France MULTIPOLYGON
france_full <- countries[countries$ISO3_CODE=="FRA", ]
mf_map(france_full)
france_morceaux <- st_cast(st_geometry(france_full), "POLYGON")
france <- france_morceaux[order(st_area(france_morceaux), decreasing = T),][c(1,3),]
mf_map(france)

# project layers
cities_FRA <- st_transform(x = cities_FRA, "EPSG:3857")
france <- st_transform(x = france, "EPSG:3857")
countries <- st_transform(x = countries, "EPSG:3857")

# display the map
mf_theme(x = "base", foreground = "#f2efe9", highlight = "#977ea2",
         mar = rep(.5, 4))
mf_map(countries, lwd = 1.5, bg = "lightblue", extent = france)
mf_shadow(france, add = TRUE)
mf_map(france, col = "#bddab1", add = TRUE)
mf_map(cities_FRA, "POP", "prop", inches = .5, lwd = 1.2, leg_pos = NA)
cex <- rep(0.8, n_villes)
cex[1:3] <- c(1.5, 1.2, 1.2)
mf_label(cities_FRA, var = "NAME", col = "gray5", overlap = FALSE, halo = TRUE,
         cex = cex, lines = FALSE, q = 3, pos = 3)
