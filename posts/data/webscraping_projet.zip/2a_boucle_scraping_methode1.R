
# Création du tableau vide que l'on souhaite remplir de nos éléments scrappés pour tous les biens
scrapimmob <- data.frame(URL = as.character(links),
                         T_court = as.character(0),
                         T_long = as.character(0),
                         Description = as.character(0),
                         Photo_1 = as.character(0),
                         Photo_2 = as.character(0),
                         Photo_3 =  as.character(0),
                         Type = as.character(0),
                         nb_ch = as.character(0),
                         nb_sdb = as.character(0),
                         surf_hab = as.character(0),
                         surf_jar = as.character(0),
                         prix = as.character(0),
                         com = as.character(0),
                         dep =  as.character(0))




##-----Scraping des éléments textes des annonces  ------------------------------

for (i in 1:nrow(scrapimmob)){   
  
  code_annonce <- read_html(scrapimmob$URL[i])
  
  # Titre court
  scrapimmob$T_court[i] <- code_annonce |> html_element("h6.display-6") |> html_text2()
  
  # Titre long
  scrapimmob$T_long[i] <- code_annonce |> html_element("h5.card-title") |> html_text2()
  
  # Description
  scrapimmob$Description[i] <- code_annonce |> html_element("p.card-text") |> html_text2()
  
  # Photo 1 (lien relatif)
  scrapimmob$Photo_1[i] <- code_annonce |> html_element("a.col-sm-3:nth-child(1) > img") |>  html_attr("src")
  
  # Photo 2
  scrapimmob$Photo_2[i] <- code_annonce |> html_element("a.col-sm-3:nth-child(2) > img") |>  html_attr("src")
  
  # Photo 3
  scrapimmob$Photo_3[i] <- code_annonce |> html_element("a.col-sm-3:nth-child(3) > img") |>  html_attr("src")
  
  # Type, Nb de chambre, de salle de bain, surface, prix, commune et département
  infos <- code_annonce |> html_elements("li.list-group-item > strong") |> html_text2()
  
  scrapimmob$Type[i] <- infos[1]
  scrapimmob$nb_ch[i] <- infos[2]
  scrapimmob$nb_sdb[i] <- infos[3]
  scrapimmob$surf_hab[i] <- infos[4]
  
  if (length(infos)==7){
    
    scrapimmob$surf_jar[i] <- NA
    scrapimmob$prix[i] <- infos[5]
    scrapimmob$com[i] <- infos[6]
    scrapimmob$dep[i] <- infos[7]
    
  } else {
    
    scrapimmob$surf_jar[i] <- infos[5]
    scrapimmob$prix[i] <- infos[6]
    scrapimmob$com[i] <- infos[7]
    scrapimmob$dep[i] <- infos[8]
    
  }
  
   print(paste0("Page ",i, " / ", nrow(scrapimmob)))
   
}


##-----Nettoyage de la base de données  ----------------------------------------


# Nettoyage des données : suppression du symbol " m²"
scrapimmob$surf_hab <- gsub(x = scrapimmob$surf_hab, pattern = " m²", replacement = "")
scrapimmob$surf_jar <- gsub(x = scrapimmob$surf_jar, pattern = " m²", replacement = "")



# Nettoyage des données :Suppression du symbole "€" 
scrapimmob$prix <- gsub(x = scrapimmob$prix, pattern = "€", replacement = "")
# Nettoyage des données :Suppression des espaces
scrapimmob$prix <- gsub(x = scrapimmob$prix, pattern = " ", replacement = "")


#  Nettoyage des données : des colonnes à convertir
col <- c("nb_ch", "nb_sdb", "surf_hab", "surf_jar", "prix")

# Nettoyage des données : Conversion des colonnes ciblées en numeric
scrapimmob[col] <- as.data.frame(lapply(scrapimmob[col], as.numeric))

# Nettoyage des données : Division de la valeur de la variable "com" avec le symbole "("
Name_and_code <- unlist(strsplit(scrapimmob$com, split = " \\(" ))

# Nettoyage des données : Transformation du vecteur en matrice + insertion dans le data.frame
scrapimmob[ c("com_name","com_insee")] <- matrix(Name_and_code, ncol = 2, byrow = TRUE)

# Nettoyage des données : Supression de la paranthèse restante dans le nouveau champ "com_insee"
scrapimmob$com_insee <- gsub(x= scrapimmob$com_insee, pattern = ")", replacement = "")


#Nettoyage des données : Division de la valeur de la variable "dep" avec le symbole "("
dep_and_reg <- unlist(strsplit(scrapimmob$dep, split = " \\(" ))

# Nettoyage des données : Transformation du vecteur en matrice + insertion dans le data.frame
scrapimmob[ c("dep_name","reg_name")] <- matrix(dep_and_reg, ncol = 2, byrow = TRUE)

# Nettoyage des données : Supression de la paranthèse restante dans le nouveau champ "com_insee"
scrapimmob$reg_name <- gsub(x= scrapimmob$reg_name, pattern = ")", replacement = "")




##-----Scraping des coordonnées géographiques  ---------------------------------

# Récupération du code source d'une page d'annonce
page <- read_html(scrapimmob$URL[1])

# Récupère des balises de type script
code_page <- page |> html_elements('script') |> html_text2()  

# Affichage du code source récupéré
code_page


# Sélection du 2e élément qui stocke les coordonées
code_page_coord <- code_page[2]

#Isoler les caractères situés entre crochet dans la balise script
coords <- strcapture(x = code_page_coord, 
                     pattern = "\\[(.*?)\\]", 
                     proto = data.frame(coordinates = character(0)))
# Les coordonnées du marqueur affiché sur la carte sont récupérés
coords

# Split de la chaîne de caractère 
unlist(strsplit(coords$coordinates, split = ", " ))

# Création de deux colonnes pour stocker les coordonnées
scrapimmob$Lat <- ""
scrapimmob$Long <- ""

for (i in 1:nrow(scrapimmob)){
  
  # Lecture du code source
  page <- read_html(scrapimmob$URL[i])
  
  # Récupération du contenu des balises script
  code_page  <- page |> html_elements('script') |> html_text2()  
  
  # Extraction des cordonnées
  coords <- strcapture(x = code_page[2], 
                       pattern = "var annonce_coords = \\[(\\d+\\.?\\d*\\, \\d+\\.?\\d*)\\]",
                       proto = data.frame(coordinates = character(0)))
  
  # Ajout des coordonées dans le data.frame scrapimmo
  scrapimmob[ c("Lat","Long")][i,] <-  unlist(strsplit(coords$coordinates, split = ", " ))
  
   print(paste0("Page ",i, " / ", nrow(scrapimmob)))
  
}  

# Conversion des coordonnées récupérées en format numeric
scrapimmob$Lat <- as.numeric(scrapimmob$Lat)
scrapimmob$Long <- as.numeric(scrapimmob$Long)



##-----Création et export objets sf  -------------------------------------------

# Transformation du tableau en objet sf
scrapimmob_sf <- st_as_sf(scrapimmob, 
                          coords = c("Long", "Lat"), 
                          crs = 'EPSG:4326')

# Affichage de la couche géographique générée
plot(scrapimmob_sf["prix"])

#Export de l'objet sf 
st_write(obj = scrapimmob_sf, 
         dsn = "data/BD_ScrapImmob.gpkg", 
         layer = "Seine_Maritime", 
         delete_layer = TRUE)



##------------------------------------------------------------------------------

#Import de la base de données si echec du scraping
##scrapimmob <- st_read("data/BD_ScrapImmob.gpkg")
