
# Installation des packages 
library(rvest)
library(DT)
library(purrr)
library(dplyr)
library(stringr)
library(tidyr)
library(sf)



##-----Exemple sur un extrait de code source  ----------------------------------


# Extrait de code source html du site ScrapImmob 
extrait_html <- "<div class='card-body'>
                      <a href='annonces/IDF_0078.html' class='stretched-link'></a>
                      <p class='card-text'>Maison charmante de 96 m² avec grand jardin à Châtenay-Malabry</p>
                  </div>"

# Interprétation du "texte" comme du code source html
basic_html <- minimal_html(extrait_html)
class(basic_html)

# Récupérer toutes les balises <p> du document
basic_html |> html_elements("p")


# Récupérer le ou les URL(s) indiquée(s) dans l'attribut href
basic_html |> html_elements("a") |> html_attr("href")

# Récupérer le contenu textuel des balises <p>
basic_html |> html_elements("p") |> html_text2()




##-----Scraping des URLs des biens  --------------------------------------------

#Lecture des pages à scrapper (version online)
url_appart <- "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/76_appartement/"
url_maison <- "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/76_maison/"
code_appart <- read_html(url_appart)
code_maison <- read_html(url_maison)


# Affichage de l'objet code_appart
code_appart


# Scrapper les URLs d'annonces de la page d'appartements 
code_appart |> html_elements("a.stretched-link") |>  html_attr("href")


#Scrapper les URLs d'annonces de la page de maisons
code_maison |> html_elements("a.stretched-link") |>  html_attr("href")


# Informations sur le nombre de pages à scrapper
nbpage_appart <- 9
nbpage_maison <- 15

# Construction des URLs pour les biens de type "appartement" (76) 
list_url_appart <- paste0(url_appart, "page_", 1:nbpage_appart,".html")

# Construction des URLs pour les biens de type "maison" (76) 
list_url_maison <- paste0(url_maison, "page_", 1:nbpage_maison,".html")

# Concaténation des deux vecteurs d'URLs
list_url <- c(list_url_appart, list_url_maison)

# Modification URL première page : page_1.html = index.html
list_url<- gsub(x = list_url, pattern =  "page_1.html", replacement = "index.html")

# Affichage du vecteur de liens
head(list_url)



# Création d'un vecteur vide
links <- character()
i<- 1
# Boucle de récupération des URLs de page d'annonce
for (i in 1:length(list_url)){

# Récupération du code source de la page i
  page <- read_html(list_url[i])
 # Récupération du lien dans les balises de la classe "stretched-link"
  links_p <- page |> html_elements("a.stretched-link") |>  html_attr("href")
  links <- c(links, links_p)
  }


# Affichage des 6 premières URLs récupérées
head(links)


#Transformation des URLs de l'URL relative "../a/b" en URL absolue "https://c/a/b"
links <- url_absolute(links, "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/a/b")

# Affichage des 6 premières URLs absolues
head(links)



##-----Exploration d'une page de bien  -----------------------------------------

# Lecture du code source de la page 1 à partir des URL scrappés
code_annonce_1 <- read_html(links[1])

#Scrapping des différentes éléments
# Titre court
code_annonce_1 |> html_element("h6.display-6") |> html_text2()

# Titre long
code_annonce_1 |> html_element("h5.card-title") |> html_text2()

# Description
code_annonce_1 |> html_element("p.card-text") |> html_text2()

# Photos (liens relatifs)
code_annonce_1 |> html_elements("img.img-fluid") |>  html_attr("src")

# Photos 1
code_annonce_1 |> html_element("a.col-sm-3:nth-child(1) > img") |>  html_attr("src")

# Photos 2
code_annonce_1 |> html_element("a.col-sm-3:nth-child(2) > img") |>  html_attr("src")

# Photos 3
code_annonce_1 |> html_element("a.col-sm-3:nth-child(3) > img") |>  html_attr("src")


# Type, Nb de chambre, de salle de bain, surfaces, prix, commune et département
code_annonce_1 |> html_elements("li.list-group-item > strong") |> html_text2()



##-----Scraping de la base de données  -----------------------------------------


#Boucle de scrapping pour toutes les biens methode 1 
#source("2_boucle_scraping_methode1.R")

#Boucle de scrapping pour toutes les biens methode 2
#source("2b_boucle_scraping_methode2.R")



##-----Exploration des données  ------------------------------------------------


#Explorer les données 
#source("3_exploration_data.R")

