
## ----Scraping des photos  ------------------------------------------------

# Reconstruction des URLs absolues
photo_1 <- url_absolute(scrapimmob$Photo_1, "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/a/b")
photo_2 <- url_absolute(scrapimmob$Photo_2, "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/a/b")
photo_3 <- url_absolute(scrapimmob$Photo_3, "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/a/b")

links_photos <- c(photo_1, photo_2, photo_3)

#Création d'un nouveau répertoire pour stocker les photos
dir.create("data/pictures") 

#Boucle de scraping des photos 
for (i in 1:length(links_photos)){
  
  # Récupération du nom de fichier
  name_file <- sub(".*/", "", links_photos[i])
  
  # Téléchargement et enregistrement de la photo
  download.file(url = links_photos[i], destfile = paste0("data/pictures/", name_file))
  
  
  print(paste0("Photo ",i, " / ", length(links_photos)))
  
}
