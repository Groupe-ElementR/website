#Création du tableau vide que l'on souhaite remplir de nos éléments scrappés pour tous les biens
scrapimmob <- data.frame(URL = as.character(links),
                         T_court = as.character(0),
                         T_long = as.character(0),
                         Description = as.character(0),
                         Photo_1 = as.character(0),
                         Photo_2 = as.character(0),
                         Photo_3 =  as.character(0),
                         Type = as.character(0),
                         nb_ch = as.character(0),
                         nb_sdb = as.character(0),
                         surf_hab = as.character(0),
                         surf_jar = as.character(0),
                         prix = as.character(0),
                         com = as.character(0),
                         dep =  as.character(0))



#Affichage du tableau vide
datatable(
  scrapimmob, 
  rownames = FALSE,  
  extensions = 'Buttons', options = list(
    dom = 'Bfrtip', pageLength = 5,
    buttons = list(list(extend = 'colvis', columns = c(1:14))), 
    columnDefs = list(list(
      targets = c(1,2,3),
      visible = TRUE, 
      render = JS(
        "function(data, type, row, meta) {",
        "  if (type === 'display') {",
        "    return data.length < 15 ? data : ",
        "      '<span title=\"' + data + '\">' + data.substr(0, 15) + '...</span>';",
        "  }",
        "  return data;",
        "}"
      )
    ))))


## ----Scraping des éléments textes des annonces  ------------------------------------------------

scrapimmob_results <- scrapimmob %>% slice(0) # Initialisation à 0 lignes du tableau de résultats

for (i in 1:nrow(scrapimmob)){   
  
  code_annonce <- read_html(scrapimmob$URL[i])
  infos <- code_annonce |> html_elements("li.list-group-item > strong") |> html_text2()
  
  scrapimmob_page <- scrapimmob %>%
    slice(i) %>%
    mutate(T_court = html_element(code_annonce, "h6.display-6") |> html_text2()) %>% # Titre court
    mutate(T_long =  html_element(code_annonce, "h5.card-title") |> html_text2()) %>% # Titre long
    mutate(Description = html_element(code_annonce, "p.card-text") |> html_text2()) %>% #Description
    mutate(Photo_1 =  html_elements(code_annonce, "img") |> html_attr('src') %>% pluck(1)) %>%
    mutate(Photo_2 =  html_elements(code_annonce, "img") |> html_attr('src') %>% pluck(2)) %>%
    mutate(Photo_3 =  html_elements(code_annonce, "img") |> html_attr('src') %>% pluck(3)) %>%
    mutate(Type = pluck(infos, 1)) %>%
    mutate(nb_ch = pluck(infos, 2)) %>%
    mutate(nb_sdb = pluck(infos, 3)) %>%
    mutate(surf_hab = pluck(infos, 4))
  
  if (length(infos)==7){
    scrapimmob_page <- scrapimmob_page %>%
      mutate(surf_jar = NA) %>%
      mutate(prix = pluck(infos, 5)) %>%
      mutate(com = pluck(infos, 6)) %>%
      mutate(dep = pluck(infos, 7))
  } else {
    scrapimmob_page <- scrapimmob_page %>%
      mutate(surf_jar = pluck(infos, 5)) %>%
      mutate(prix = pluck(infos, 6)) %>%
      mutate(com = pluck(infos, 7)) %>%
      mutate(dep = pluck(infos, 8))
  }
  
  scrapimmob_results <- scrapimmob_results %>%
    bind_rows(scrapimmob_page)
  
  print(paste0(i, " / ", nrow(scrapimmob)))
  
}

scrapimmob <- scrapimmob_results



## ----Nettoyage de la base de données  ------------------------------------------------


scrapimmob <- scrapimmob %>%
  # 1) **Suppression des unités de mesure** pour les prix et les surfaces collectés.
  mutate(surf_hab = str_remove(surf_hab, " m²") %>% as.numeric()) %>% # Suppression du symbol " m²"
  mutate(surf_jar = str_remove(surf_jar, " m²") %>% as.numeric()) %>% # Suppression du symbol " m²"
  mutate(prix = str_remove(prix, "€") %>% str_remove(., " ")) %>% # Suppression du symbole "€" et des espaces
  # 2) **Conversion des nombres** stockés en `string` en format `numeric`.
  mutate(across(
    .cols = c(starts_with("nb_"), starts_with("surf_"), prix),
    .fns = as.numeric
  )) %>%
  # 3) **Ventilation de la variable "com"** en deux colonnes : "com_name" et "com_insee" et Idem pour variable "dep"
  separate_wider_delim(com, delim = "(", names = c("com_name", "com_insee")) %>% # Division en deux colonnes
  separate_wider_delim(dep, delim = "(", names = c("dep_name", "reg_name")) %>% # Division en deux colonnes
  mutate(com_insee = str_remove(com_insee, fixed(")"))) %>% # Suppression des parenthèses fermantes restantes
  mutate(reg_name = str_remove(reg_name, fixed(")"))) %>% # Suppression des parenthèses fermantes restantes
  mutate(reg_name = paste0("    ", reg_name)) %>%
  mutate(across(  # Suppression des espaces en début et fin
    .cols = c(com_name, com_insee, dep_name, reg_name),
    .fns = str_trim))



## ----Scraping des coordonnées géographiques  ------------------------------------------------

# Récupération du code source d'une page d'annonce
page <- read_html(scrapimmob$URL[1])

# Récupère des balises de type script
code_page <- page |> html_elements('script') |> html_text2()  

# Affichage du code source récupéré
code_page


# Sélection du 2e élément qui stocke les coordonées
code_page_coord <- code_page[2]

#Isoler les caractères situés entre crochet dans la balise script
coords <- str_extract(code_page_coord,"\\[(.*?)\\]", group = 1) %>%
  str_split(", ", simplify = TRUE) %>% # Séparation des 2 coordonnées
  as.numeric()# Conversion en numérique

# Les coordonnées du marqueur affiché sur la carte sont récupérés
coords


scrapimmob_results <- scrapimmob %>% slice(0)
for (i in 1:nrow(scrapimmob)){
  
  # Lecture du code source
  scrapimmob_page <- scrapimmob %>% slice(i)
  coords <- read_html(scrapimmob_page %>% pull(URL)) %>%
    html_elements('script') %>% # Récupération de la balise script
    html_text2() %>% # Conversion en texte
    pluck(2) %>% # Seule la deuxième balise script contient les coordonnées
    str_extract("\\[(.*?)\\]", group = 1) %>% # Extraction des coordonnées entre crochets
    str_split(", ", simplify = TRUE) %>% # Séparation des 2 coordonnées
    as.numeric()# Conversion en numérique
  
  scrapimmob_results <- scrapimmob_results %>%
    bind_rows(
      scrapimmob_page %>%
        mutate(Lat = coords[1]) %>%
        mutate(Long = coords[2])
    )
  print(paste0(i, " / ", nrow(scrapimmob)))
}

scrapimmob <- scrapimmob_results


## ----Création et export objets sf  ------------------------------------------------

# Transformation du tableau en objet sf
scrapimmob_sf <- st_as_sf(scrapimmob, 
                          coords = c("Long", "Lat"), 
                          crs = 'EPSG:4326')

# Affichage de la couche géographique générée
plot(scrapimmob_sf["prix"])

#Export de l'objet sf 
st_write(obj = scrapimmob_sf, 
         dsn = "data/BD_ScrapImmob.gpkg", 
         layer = "Seine_Maritime", 
         delete_layer = TRUE)


## ----Scraping des photos  ------------------------------------------------

# Reconstruction des URLs absolues
photo_1 <- url_absolute(scrapimmob$Photo_1, "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/a/b")
photo_2 <- url_absolute(scrapimmob$Photo_2, "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/a/b")
photo_3 <- url_absolute(scrapimmob$Photo_3, "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/a/b")

links_photos <- c(photo_1, photo_2, photo_3)

#Création d'un nouveau répertoire pour stocker les photos
dir.create("data/pictures") 

#Boucle de scraping des photos 
for (i in 1:length(links_photos)){
  
  # Récupération du nom de fichier
  name_file <- sub(".*/", "", links_photos[i])
  
  # Téléchargement et enregistrement de la photo
  download.file(url = links_photos[i], destfile = paste0("data/pictures/", name_file))
  
}



#Import de la base de données si echec du scraping
##scrapimmob <- st_read("data/BD_ScrapImmob.gpkg")
