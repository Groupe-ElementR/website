#Packages utilisés
library(ggplot2)
library(tm)
library(wordcloud)
library(leaflet) 

#Import de la base de données si echec du scraping
#scrapimmob <- st_read("data/BD_ScrapImmob.gpkg")

## ----Analyse graphique ------------------------------------------------

#Graphique en barre représentant le nombre de biens en vente par type 
ggplot(scrapimmob) +
  aes(x = Type) +
  geom_bar(fill = "#4682B4") +
  labs(y = "Nombre de biens", title = "Répartition du nombre de biens, par type") +
  coord_flip() +
  theme_gray() +
  theme(plot.title = element_text(size = 14L, face = "bold"))



#Graphique en barre représentant le nombre de biens en vente par commune normande
ggplot(scrapimmob) +
  aes(x = com_name) +
  geom_bar(fill = "#4682B4") +
  labs(y = "Nombre de biens en vente", title = "Répartition du nombre de biens par commune") +
  ylab("") +
  coord_flip() +
  theme_gray() +
  theme(plot.title = element_text(size = 11L, face = "bold"), axis.text=element_text(size=6.5))



#Distribution des surfaces habitables par types de biens
ggplot(scrapimmob) +
  aes(x = Type, y = surf_hab, color=Type) +
  geom_boxplot() +
  geom_jitter() +
  labs(y = "Surface en m2", 
       title = "Les surfaces habitables selon le type de bien") +
  theme_gray() +
  theme(plot.title = element_text(size = 14L, 
                                  face = "bold"))



# Distribution des surfaces habitables en fonction du prix de mise en vente :
ggplot(scrapimmob) +
  aes(x=prix, y=surf_hab, color = Type) +
  geom_point()


#Distribution des prix par types de biens
# Pour affichage de chiffre dans le graphique
options(scipen = 999)

# Sélection des maisons uniquement
scrapimmobmaison <- scrapimmob[scrapimmob$Type == "Maison",]

# Regroupement par commune
table <- aggregate(x = scrapimmobmaison$prix, by = list(scrapimmobmaison$com_name), FUN=median)

# Graphique 
ggplot(data=table) +
  aes(x = reorder(Group.1, -x), y = x) +
  geom_col(fill = "#4682B4", colour = "white", linewidth = 0.05) +
  coord_flip() +
  labs(
    title = "Le prix des maisons en vente par commune",
    x = "Prix médian",
    y = "") +
  theme_gray() +
  theme(plot.title = element_text(size = 12L, face = "bold"), axis.text=element_text(size=6.5))








## ----Analyse textuelle ------------------------------------------------


# Création du corpus
corpus <- Corpus(VectorSource(scrapimmob$Description))

# Traitement du texte
corpus <- tm_map(corpus, content_transformer(tolower))
corpus <- tm_map(corpus, content_transformer(function(x) iconv(enc2utf8(x), sub = "byte")))
corpus <- tm_map(corpus, removeWords, stopwords("french"))
corpus <- tm_map(corpus, removePunctuation)
corpus <- tm_map(corpus, removeNumbers)

# Fonction de nettoyage personnalisée pour supprimer les motifs spécifiques
enlever_symbols <- content_transformer(function(x, pattern) gsub(pattern, "", x))

# Appliquer la fonction pour enlever '€' et 'm²'
corpus <- tm_map(corpus, enlever_symbols, "€")
corpus <- tm_map(corpus, enlever_symbols, "m²")

#Nuage de mots
wordcloud(corpus, 
          scale = c(2.5,0.5), 
          max.words = 50, 
          min.freq = 2,
          random.order = FALSE,
          colors = rev(terrain.colors(8)))



## ----Carte interactive ------------------------------------------------

scrapimmob_sf$Photo_1 <- url_absolute(scrapimmob_sf$Photo_1, "https://analytics.huma-num.fr/Robin.Cura/ScrapImmob/a/b")

leaflet(scrapimmob_sf) |>
  addTiles() |>
  addCircleMarkers(
    popup = ~paste("<strong>", T_court, "</strong>",
                   "<br><img src='", Photo_1 ,"' style='width:200px;height:200px;'>",
                   "<br><strong>Type :</strong>", Type, 
                   "<br><strong>Surface habitable :</strong>", surf_hab,"m²",
                   "<br><strong>Nombre de chambres :</strong>", nb_ch, "</strong>", 
                   "<br><strong>Nombre de salles de bains :</strong>", nb_sdb, "</strong>",
                   "<br><strong>Prix :</strong>", prix, "€"),
    label = ~T_court, 
    radius = 3,
    color = ~ifelse(Type == "Appartement", "#0C3762", "#F0AA0C"),
    fillOpacity = 0.8)



