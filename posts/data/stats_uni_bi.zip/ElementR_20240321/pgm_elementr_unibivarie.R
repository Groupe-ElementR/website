# ...........................................
#
# type de pgm : script
# auteur : Sylvestre Duroudier
# cree le 21/03/2024
# derniere version le 21/03/2024
# 
# description : séance ElementR sur les statistiques univariées et bivariées
#
# ...........................................



# ...........................................
# 1. IMPORTS ----
# ...........................................

getwd()
setwd("C:/Users/Sylvestre/Documents/2 - Animations et suivi/2024 - ElementR - Uni et bivarié")


# 1.1 packages ====
# ...........................................

# install.packages(tidyverse)
# install.packages(sf)
# install.packages(lmtest)
# install.packages(RColorBrewer)
# install.packages(ggplot2)
# install.packages(tmap)

library(tidyverse)
library(sf)
library(lmtest)
library(RColorBrewer)
library(ggplot2)
library(tmap)


# 1.2 Imports  ====
# ...........................................


# données
# dbmob <- read_csv2("DB_Mobpro by counties_20162020.csv", col_names = TRUE)
db <- read_csv2("db_cbsa_race_2020.csv", col_names = TRUE)
db <- db %>%
  mutate(CBSAA = as.character(CBSAA)) %>%
  filter(!State %in% c("AK", "HI", "PR"))


# fond de carte
fdc_cities <- st_read("US_cbsa_2020_light.shp")
st_crs(fdc_cities)
plot(fdc_cities$geometry)

fdc_states <- st_read("US_state_2019_light.shp")
st_crs(fdc_states)
plot(fdc_states$geometry)
fdc_states <- fdc_states %>%
  filter(!STUSPS %in% c("AK", "HI", "PR"))
plot(fdc_states$geometry)



# ...........................................
# 2. ANALYSE UNIVARIEE ----
# ...........................................

# 2.1 Résumé statistique  ====
# ...........................................


# obtenir un résumé partiel d'une variable
summary(db$HISPA)
## la fonction reprend min(), max(), median(), mean(), quantile(,0.25), quantile(,0.75)

# obtenir un résumé d'un ensemble de variables 
summary(db)

# problème pour les variables qualitatives
summary(as.factor(db$DEFI))
summary(as.factor(db$Region))

# juste les indices de ségrégation
summary(db[,19:23], digits = 2)


# 2.2 Indicateurs de position  ====
# ...........................................

min(db$HISPA) # minimum
max(db$HISPA) # maximum
mean(db$HISPA) # moyenne
median(db$HISPA) # mediane

# 2.3 Indicateurs de dispersion  ====
# ...........................................

range(db$HISPA) # étendue
var(db$HISPA) # variance
sd(db$HISPA) # ecart-type
sd(db$HISPA) / mean(db$HISPA) # coefficient de variation
quantile(db$HISPA, 0.25) # quartile 1
quantile(db$HISPA, 0.9) # décile 9


# 2.4 Mode (variables qualitatives)  ====
# ...........................................

table(db$DEFI)

## une variante utile
# install.packages(questionr)
library(questionr)
defi <- freq(db$DEFI,
             cum = FALSE,
             total = TRUE)
defi


# 2.5 Graphiques  ====
# ...........................................

# Variable quantitative = histogramme
graph <- ggplot(db, aes(x = HISPA))+
  geom_histogram(binwidth = 100000) +
  theme_bw() +
  labs(
    title = "Distribution du nombre d'Hispaniques dans les aires métropolitaines des Etats-Unis",
    x = "Nombre d'Hispaniques",
    y = "Nombre d'aires métropolitaines"
  )
graph

graph <- ggplot(db, aes(x = HISPA)) +
  geom_histogram() +
  scale_x_log10() +
  theme_bw() +
  labs(
    title = "Distribution du nombre d'Hispaniques dans les aires métropolitaines des Etats-Unis",
    x = "Nombre d'Hispaniques",
    y = "Nombre d'aires métropolitaines"
  )
graph

# variable qualitative = diagramme en barre
graph <- ggplot(db, aes(x = DEFI))+
  geom_bar() + 
  theme_bw() +
  scale_y_log10() +
  labs(
    title = "Distribution des aires métropolitaines des Etats-Unis selon leur catégorie de taille",
    x = "Catégorie de taille de ville",
    y = "Nombre d'aires métropolitaines"
  )
graph


# 2.6 Exercices ====
# ...........................................

# Par des calculs et des graphiques :

# 1. Identifier la répartition des villes selon les régions.
### Quelle est la région modale ?
### Quelle est la région comptant le moins de villes ?

# 2. Déterminer la forme de la distribution des Noirs dans les villes des Etats-Unis.
### Quelle est l'étendue ?
### Quel est le coefficient de variation ?
### A quel pourcentage est le décile des villes ayant le moins de Noirs en poids relatif ?

# 3. Idem pour l'indice de ségrégation des Noirs
### Quelles sont les moyennes et médianes ?
### Le coefficient de variation est-il supérieur ou inférieur à celui du pourcentage de Noirs ?





# ...........................................
# 3. BIVARIE QUANTITATIF ----
# ...........................................

# 3.1 Graphique ====
# ...........................................

# Référentiel arithmétique
graph <- ggplot(db, aes(x = POP20, y = HISPA)) +
  geom_point(alpha = 1, 
             shape = 21, 
             color = "white", 
             fill = "black", 
             stroke = 1/20, 
             aes(size = POP20)) +
  theme_bw() +
  labs(title ="Population hispanique selon la taille des aires métropolitaines aux Etats-Unis",
       x = "Population en 2020", y = "Nombre d'Hispaniques en 2020") +
  theme(legend.position = "bottom")
graph

# Référentiel logarithmique
graph <- ggplot(db, aes(x = POP20, y = HISPA)) +
  geom_point(alpha = 1, 
             shape = 21, 
             color = "white", 
             fill = "black", 
             stroke = 1/20, 
             aes(size = POP20)) +
  scale_x_log10() +
  scale_y_log10() +
  theme_bw() +
  labs(title ="Population hispanique selon la taille des aires métropolitaines aux Etats-Unis",
       x = "Population en 2020", y = "Nombre d'Hispaniques en 2020") +
  theme(legend.position = "bottom")
graph


# 3.2 Corrélations ====
# ...........................................

# relation entre 2 variables
cor(x = db$HISPA, y = db$POP20, method = "pearson", use = "all.obs")
cor(x = db$HISPA, y = db$POP20, method = "spearman", use = "all.obs")


# relation entre plein de variables
## fonctions successives
cor(db[,9:23])
round(cor(db[,9:23]), digits = 1)
correl <- round(cor(db[,9:23]), digits = 1)
correl <- as.data.frame(round(cor(db[,9:23]), digits = 1)) 
## chaînage
correl <- cor(db[,9:23]) %>%
  round(digits = 1) %>%
  as.data.frame() %>%
  mutate(CBSA = row.names(correl)) %>%
  select(CBSA, WHITE:OTHERis)
## Export
write_csv2(correl, "correlation.csv")



# 3.3 Modèle de régression linéaire ====
# ...........................................

## définition X et Y
Y = db$HISPA
X = db$POP20
## modele
model1 <- lm(Y ~ X) # exemple de base
model1 <- lm(data = db, HISPA ~ POP20) # variante dans un tableau
model1 # appeler le modèle fournit l'équation
summary(model1) # résultats généraux : equation, variabilité des résidus, coefficients, variance expliquée, significativité
## Jeter un oeil aux résidus
anova(model1) # analyse de la variance des résultats (si hétéroscédasticité)
hist(model1$residuals) # histogramme rapide
bptest(model1) # test de Breusch-Pagan sur la normalité des résidus

## visualisation du modèle
graph <- graph +
  geom_abline(intercept = model1$coefficients[1], slope = model1$coefficients[2], col="red")
graph
### Export carte
ggsave(plot = graph, device = "pdf", filename = "mongraph.pdf", units = "cm", width = 22, height = 15)


# 3.4 Analyse des résidus ====
# ...........................................

# analyse des résidus
## exporter les résidus
str(model1) # voir ce que contient l'objet lm
estim <- as.data.frame(fitted(model1))
head(estim)
res <- as.data.frame(resid(model1))
head(res)
results <- cbind(db, estim, res)
results <- results %>%
  rename(estimate = `fitted(model1)`,
         residus = `resid(model1)`)
## Calcul des résidus relatifs
results <- results %>%
  mutate(RR = (residus/estimate))
head(results)
summary(results[,25:26])

## histogramme travaillé
#### outils : ggplot2
graph <- ggplot(results, aes(residus)) +
  geom_histogram() +
  scale_y_log10() +
  theme_bw()
graph



# 3.5 Cartographie des résidus ====
# ...........................................

## Cartographie
#### outils : tmap, colorbrewer
tomap <- left_join(fdc_cities, results, by = c("GEOID" = "CBSAA"))

### carte de base
map <- tm_shape(fdc_states) +
  tm_polygons(col = "white", alpha = 0, border.col = "black", border.lwd = 1, border.alpha = 0) +
  tm_shape(tomap) +
  tm_polygons(col = "residus",
              style = "pretty",
              # breaks = c(-2, -1, -0.5, 0, 0.5, 1, 2, 3),
              palette = "-RdBu",
              alpha = 1,
              border.col = "grey30", 
              border.lwd = 0.2,
              border.alpha = 1,
  ) +
  tm_shape(fdc_states) +
  tm_polygons(col = "white", alpha = 0, border.col = "black", border.lwd = 1, border.alpha = 1) +
  tm_legend(legend.position = c("left", "bottom"),
            legend.outside = T) +
  tm_credits(align = "left", size = 0.7, text = "Résidus d'un super modèle
Source : US Bureau of Census, 2010 ; 2013 ; 2020.. 
Cartographie : Sylvestre Duroudier, 2024.", 
             position = c("left", "bottom")) +
  tm_layout(legend.title.size = 0.7,
            legend.text.size = 0.7) +
  tm_scale_bar(color.dark = "gray60", position = c("right", "bottom"))
map

### variante avec population des villes
map <- tm_shape(fdc_states) +
  tm_polygons(col = "white", alpha = 0, border.col = "black", border.lwd = 1, border.alpha = 1) +
  tm_shape(tomap) +
  tm_bubbles(size = "POP20",
             scale = 5,
             col = "residus",
             style = "pretty",
             # breaks = c(-2, -1, -0.5, 0, 0.5, 1, 2, 3),
             palette = "-RdBu",
             alpha = 1,
             border.col = "grey30", 
             border.lwd = 0.2,
             border.alpha = 1,
  ) +
  tm_legend(legend.position = c("left", "bottom"),
            legend.outside = T) +
  tm_credits(align = "left", size = 0.7, text = "Résidus d'un super modèle
Source : US Bureau of Census, 2010 ; 2013 ; 2020.. 
Cartographie : Sylvestre Duroudier, 2024.", 
             position = c("left", "bottom")) +
  tm_layout(legend.title.size = 0.7,
            legend.text.size = 0.7) +
  tm_scale_bar(color.dark = "gray60", position = c("right", "bottom"))
map

### variante résidus relatifs
map <- tm_shape(fdc_states) +
  tm_polygons(col = "white", alpha = 0, border.col = "black", border.lwd = 1, border.alpha = ) +
  tm_shape(tomap) +
  tm_bubbles(size = "POP20",
             scale = 5,
             col = "RR",
             breaks = c(-4, -3, -2, -1, -0.5, 0, 0.5, 1),
             palette = "RdBu",
             alpha = 1,
             border.col = "grey30", 
             border.lwd = 0.2,
             border.alpha = 1,
  ) +
  # tm_shape(fdc_states) +
  # tm_polygons(col = "white", alpha = 0, border.col = "black", border.lwd = 1, border.alpha = 1) +
  tm_legend(legend.position = c("left", "bottom"),
            legend.outside = T) +
  tm_credits(align = "left", size = 0.7, text = "Résidus d'un super modèle
Source : US Bureau of Census, 2010 ; 2013 ; 2020. 
Cartographie : Sylvestre Duroudier, 2024.", 
             position = c("left", "bottom")) +
  tm_layout(legend.title.size = 0.7,
            legend.text.size = 0.7) +
  tm_scale_bar(color.dark = "gray60", position = c("right", "bottom"))
map

### Export carte
tmap_save(map, filename = "macarte.pdf", units = "cm", width = 22, height = 15)




# 3.6 Exercices ====
# ...........................................

# Examiner la relation entre deux caractères quantitatifs au choix
# Réaliser et interpréter un modèle de régression liéaire
# Cartographier les résidus du modèle




# ...........................................
# 4. BIVARIE QUALITATIF ----
# ...........................................


# 4.1 Dénombrement des effectifs ====
# ...........................................

# Tableau de dénombrement
denomb <- table(db$DEFI, db$Region)
denomb

## Possibilité de créer des objets et de les exporter
tabdenomb <- as.data.frame(denomb)
## Attention format long
tabdenomb <- tabdenomb %>%
  pivot_wider(names_from = Var2, values_from = Freq)

# Pourcentages (au format large)
## pourcentages totaux
pertot <- as.data.frame(round(100*prop.table(denomb,margin=),1)) %>%
  pivot_wider(names_from = Var2, values_from = Freq)
## Pourcentages en lignes
perli <- as.data.frame(round(100*prop.table(denomb,margin=1),1)) %>%
  pivot_wider(names_from = Var2, values_from = Freq)
## Pourcentages en colonnes
percol <- as.data.frame(round(100*prop.table(denomb,margin=2),1)) %>%
  pivot_wider(names_from = Var2, values_from = Freq)


# 4.2 Graphique ====
# ...........................................

# Pour les graphiques, o a besoin d'un format long
perli <- as.data.frame(round(100*prop.table(denomb,margin=1),1))
percol <- as.data.frame(round(100*prop.table(denomb,margin=2),1))

graph <- ggplot(percol, aes(x = Var2, y = Freq, fill = Var1)) +
  geom_col(position = "dodge", width = 0.9, color = "black") +
  theme_bw() +
  labs(
    title = "Distribution régionale des villes selon leur taille",
    x = "Régions",
    y = "Pourcentages de villes"
  )
graph

graph <- ggplot(perli, aes(x = Var2, y = Freq, fill = Var1)) +
  geom_col(position = "dodge", width = 0.9, color = "black") +
  theme_bw() +
  labs(
    title = "Distribution régionale des villes selon leur taille",
    x = "Régions",
    y = "Pourcentage des villes dans chaque catégorie de taille"
  )
graph



# 4.3 Test du Chi-2 ====
# ...........................................

# Calcul
test <- chisq.test(db$DEFI, db$Region)

# Visualisation des résultats
test

# Résultats détaillés
test$observed
round(test$expected, 1)
round(test$residuals, 2)
resi <- as.data.frame(round(test$residuals, 2))

graph <- ggplot(resi, aes(x = db.Region, y = Freq, fill = db.DEFI)) +
  geom_col(position = "dodge", width = 0.9, color = "black") +
  theme_bw() +
  labs(
    title = "Distribution régionale des villes selon leur taille",
    x = "Catégories des villes selon leur taille",
    y = "Pourcentage des régions"
  )
graph


# 4.4 Exercices ====
# ...........................................

# Examiner la relation entre le type de villes (CBSAtype) et les régions (Region)
## Quel est le pourcentage des villes Metro situées dans la région 4 ?
## Quel est le pourcentage des villes de la région 4 qui sont Micro ?
## Est-ce que les résultats du test du Chi-2 permettent de conclure à l'existence d'un relation entre ces deux caractères ?



# ...........................................
# 5. BIVARIE QUALI-QUANTI ----
# ...........................................

# 5.1 Dénombrement ====
# ...........................................

# Dénombrement qui ne fonctionne pas...
table(db$Region, db$HISPA)

# il faut grouper par variable qualitative
resume <- db %>%
  group_by(Region) %>%
  summarise(moyenne = mean(HISPA),
            mediane = median(HISPA),
            ecarttype = sd(HISPA))
resume


# 5.2 Graphique ====
# ...........................................

graph <- ggplot(db, aes(x = as.character(Region), 
                        y = HISPA, 
                        fill = as.character(Region))) +
  geom_boxplot() +
  scale_y_log10() +
  theme_bw() +
  labs(
    title = "Distribution régionale des villes selon leur taille",
    x = "Régions",
    y = "Nombre d'Hispaniques"
  )
graph


# 5.3 Analayse de la variance ====
# ...........................................

# Réalisation d'un test de Fischer
# définition X et Y
Y = db$HISPA
X = db$Region
# modèle
model2 <- lm(Y ~ X)
# résultats
anova(model2)
summary(model2)


# 5.4 Analyse des résidus ====
# ...........................................

# Graphique
graph <- ggplot(db, aes(x = as.character(Region), 
                        y = HISPA, 
                        fill = as.character(Region))) +
  geom_boxplot() +
  scale_y_log10() +
  theme_bw() +
  labs(
    title = "Distribution régionale des villes selon leur taille",
    x = "Régions",
    y = "Nombre d'Hispaniques"
  )
graph

# analyse des résidus
## exporter les résidus
str(model2) # voir ce que contient l'objet lm
estim <- as.data.frame(fitted(model2))
head(estim)
res <- as.data.frame(resid(model2))
head(res)
results <- cbind(db, estim, res)
results <- results %>%
  rename(estimate = `fitted(model2)`,
         residus = `resid(model2)`)
## Calcul des résidus relatifs
results <- results %>%
  mutate(RR = (residus/estimate))
head(results)
summary(results[,25:26])


# 5.5 Cartographie des résidus ====
# ...........................................

tomap <- left_join(fdc_cities, results, by = c("GEOID" = "CBSAA"))

### carte de base
map <- tm_shape(fdc_states) +
  tm_polygons(col = "white", alpha = 0, border.col = "black", border.lwd = 1, border.alpha = 0) +
  tm_shape(tomap) +
  tm_polygons(col = "residus",
              style = "pretty",
              # breaks = c(-2, -1, -0.5, 0, 0.5, 1, 2, 3),
              palette = "-RdBu",
              alpha = 1,
              border.col = "grey30", 
              border.lwd = 0.2,
              border.alpha = 1,
  ) +
  tm_shape(fdc_states) +
  tm_polygons(col = "white", alpha = 0, border.col = "black", border.lwd = 1, border.alpha = 1) +
  tm_legend(legend.position = c("left", "bottom"),
            legend.outside = T) +
  tm_credits(align = "left", size = 0.7, text = "Résidus d'un super modèle
Source : US Bureau of Census, 2010 ; 2013 ; 2020.. 
Cartographie : Sylvestre Duroudier, 2024.", 
             position = c("left", "bottom")) +
  tm_layout(legend.title.size = 0.7,
            legend.text.size = 0.7) +
  tm_scale_bar(color.dark = "gray60", position = c("right", "bottom"))
map

### variante avec population des villes
map <- tm_shape(fdc_states) +
  tm_polygons(col = "white", alpha = 0, border.col = "black", border.lwd = 1, border.alpha = 1) +
  tm_shape(tomap) +
  tm_bubbles(size = "POP20",
             scale = 5,
             col = "residus",
             style = "pretty",
             # breaks = c(-2, -1, -0.5, 0, 0.5, 1, 2, 3),
             palette = "-RdBu",
             alpha = 1,
             border.col = "grey30", 
             border.lwd = 0.2,
             border.alpha = 1,
  ) +
  tm_legend(legend.position = c("left", "bottom"),
            legend.outside = T) +
  tm_credits(align = "left", size = 0.7, text = "Résidus d'un super modèle
Source : US Bureau of Census, 2010 ; 2013 ; 2020.. 
Cartographie : Sylvestre Duroudier, 2024.", 
             position = c("left", "bottom")) +
  tm_layout(legend.title.size = 0.7,
            legend.text.size = 0.7) +
  tm_scale_bar(color.dark = "gray60", position = c("right", "bottom"))
map

# 5.6 Exercices ====
# ...........................................