# Atelier ElementR du 14.02.23 14h - 17h
# 
#____________Analyse d'une enquête auprès des voyageurs SNCF, 2021______________
#
#                                            Marion Albertelli & Joséphin Béraud
#
# -----------------------------------------------------------------------------#

# LES INSTALLATIONS ---- 
# install.packages("tidyverse")
# install.packages("skimr")
# install.packages("questionr")
# install.packages("gtsummary")

library(tidyverse)
# ou les packages suivants 
# library(readr)
# library(stringr)
# library(tidyr)
# library(ggplot2)
# library(dplyr)

library(skimr)
library(questionr)
library(gtsummary)

# - L'IMPORT DES DONNNEES ----
enquetev <- read.csv("data/enquetev.csv", header=TRUE, sep=";", fileEncoding = "UTF-8")
typologie <- read.csv("data/typologie.csv", header = TRUE, fileEncoding = "UTF-8")

# Vérifier les gares enquêtées + leur orthographe
sort(unique(enquetev$RS3))

# Suppression des majuscules dans les noms de gare.
enquetev$RS3 <- tolower(enquetev$RS3)
# ou pour 1 seul nom (mais moins utile ici)
enquetev$RS3 <- gsub("ParisGaredeLyon", "parisgaredelyon", enquetev$RS3)

# - DECOUVERTE DES DONNEES ----

# Quelle est la nature d'un CSV qu'on importe dans R avec cette fonction là ? 
class(enquetev)
# pour avoir le nom des colonnes
names(enquetev)
# Prévisualisation de mon tableau de données
View(enquetev)
# ou dans la console : les 5 premières lignes
head(enquetev)
# Combien de lignes et de colonnes comportent mon tableau ?
dim(enquetev)
# ou 
ncol(enquetev)
nrow(enquetev)
# De quelle nature sont mes données ?
str(enquetev)

# TABLEAU DE FREQUENCE ----

# Tableau de fréquence nb enquêtés/mode
questionr::freq(enquetev$Q4) 

# Tableau de fréquence par mode et par gare
df_enq_mode_gare <-enquetev %>%
  filter(RS3 %in% c("rouenrivedroite", "lillesflandres","parisgaredebercy")) %>%
  group_by(RS3, Q4) %>%
  summarise(Individu = n())%>%
  drop_na()

# Création d'un tableau de fréquence simple et propre avec plusieurs variables
enquetev %>%
  tbl_summary(include = c("RS3", "Q4", "RS6"))

# TEMPS DE TRAJET MOYEN ---- 
# Moyenne des temps de trajet pour se rendre à la gare (Q12).

# De quel type est la variable 
class(enquetev$Q12)

# Résumé statistique 
summary(enquetev$Q12, na.rm=TRUE)

# Calculer la moyenne des temps de trajet pour chacune des 5 gares de l'enquête
moy_trajet <- enquetev %>%
  group_by(RS3) %>% # groupe par gare 
  summarize(moy = round(mean(Q12, na.rm = TRUE),0))

# Réprésentation en point de temps de trajet moyen
ggplot(moy_trajet, aes(y = moy)) +
  geom_point(aes(x = RS3)) +
  ggtitle("Temps moyen de trajet par gare") +
  xlab("Gare") +
  ylab("temps de trajet moyen")

# Représentation en barre 
ggplot(data  =moy_trajet, aes(x = RS3, y = moy)) + 
  geom_col(color="red", fill="blue") + 
  geom_text(aes(label = moy, vjust = 1.6, color = "white", size = 3.5)) +
  theme_minimal() +
  xlab("Gare") +
  ylab("Temps de trajet moyen en minute") +
  ggtitle("Temps moyen de trajet par gare")

# ANALYSES UNI-VARIEES ---- 

# Création d'un tableau de fréquence simple et propre avec plusieurs variables
enquetev %>%
  tbl_summary(include = c("RS3", "Q4", "RS6"))

# Estimation par noyau de la distribution du nombre de min pour les trajets
plot(density(enquetev$Q12, bw = 5, na.rm = TRUE), main = "Temps de trajet")

# Répartition empirique de la durée des trajets pour se rendre en gare
plot(ecdf(enquetev$Q12), main = "Temps de trajet")

# Boîte à moustache de la variable temps de trajet
boxplot(enquetev$Q12, main = "Temps de trajet", ylab = "Minutes")
# Suppression des valeurs exceptionnelles
boxplot(enquetev$Q12, main = "Temps de trajet", ylab = "Minutes", outline = FALSE)


# Croisement temps de trajet/genre 
boxplot(Q12 ~ Q38, data = enquetev)
boxplot(Q12 ~ Q38, data = enquetev, outline = FALSE)

# TEST DU CHI² ---- 

# Test du chi² sur le genre et le nombre de mode utilisés 

# Convertit la Q38 en facteur
enquetev <- enquetev %>%
  mutate(Q38 = as.factor(Q38))

# Séléction et filtres des variables:
df_genre_mode <- enquetev %>%
  select(Q38, Q11_R1) %>%
  filter(Q38 %in% c("Femme", "Homme")) %>%
  filter(Q11_R1 != "")

# Test du chi²
# ?chisq.test
# ?table
chisq.test(table(df_genre_mode$Q38, df_genre_mode$Q11_R1)) # Message d'avertissement ? 

## On regarde pourquoi :

# Avec une fonction R-base
table(df_genre_mode$Q38, df_genre_mode$Q11_R1) # Il une case où il n'y a que 4 individus

# Avec dplyr (tidyverse)
df_genre_mode %>%
  group_by(Q38, Q11_R1) %>%
  summarise(Individu = n()) 


# Recodage de la variable pour répondre aux exigences du test
# Onglet Addins -> Level recoding, qui génère le code suivant à exécuter :
df_genre_mode$Q11_R1_rec <- df_genre_mode$Q11_R1 %>%
  fct_recode(
    "3modes+" = "3modes",
    "3modes+" = "4modes"
  )

# Vérification du regroupement de modalités réalisé
table(df_genre_mode$Q38, df_genre_mode$Q11_R1_rec) 

# Test du chi² 
chisq.test(table(df_genre_mode$Q38, df_genre_mode$Q11_R1_rec)) # Il ne reste qu'à l'interpréter !

# ANALYSE BIVARIEE -- 

# Graphe en mosaique
mosaicplot(RS7 ~ Q38, 
           data = enquetev, shade = TRUE, 
           las=1.5, main = "Fréquentation de la gare selon le genre")


# JOINTURE ---- 

# On veut savoir le pourcentage que représente les enquêtés par rapport au nombre de voyageurs à l'année 

# Création d'un id commun avec la typologie (clé de jointure)
enquetev$id_gare <- case_when(enquetev$RS3 == "lillesflandres" ~ 8,
                              enquetev$RS3 == "parisgaredebercy" ~ 21,
                              enquetev$RS3 == "rouenrivedroite" ~ 27)
unique(enquetev$id_gare)

# Calcul le nombre d'enquêtés par gare
enquetev_g <- enquetev %>%
  group_by(id_gare, RS3) %>% count() 

# Sélection des colonnes pour la jointure
nb_v <- typologie %>%
  select(id_gare, Nb_v_2019) # Seulement l'identifiant (clé de jointure) et le nombre de voyageurs à l'année

# Fait la jointure 
# ?left_join
# On aurait pu utiliser merge (Rbase)
result_jointure <- left_join(enquetev_g, nb_v, by = "id_gare")

# On calcule le pourcentage
result_jointure $pourc <- result_jointure $n / result_jointure $Nb_v_2019 *100

result_jointure 



# BONUS : CARTOGRAPHIE ---- 

# Représenter le temps de trajet moyen pour aller à la gare de Bercy 
# depuis la petite couronne

# install.packages("sf")
# install.packages("mapsf")
library(sf) # pour lire les fichier spatiaux 
library(mapsf) # pour faire la cartographie 

# Temps trajet moyen gare vers Bercy
trajet_bercy <- enquetev %>%
  select(RS3, # Gare enquêtée 
         RS5, # Type voyageur (entrant, sortant)
         Q3.INSEE, # Code Insee Commune
         Q12 # Temps de trajet
  ) %>%
  filter(RS5 == "Voyageurentrant", RS3 == "parisgaredebercy") %>% # Garde que les voyageurs entrant
  drop_na() %>% # enlève les NA
  group_by(RS3, Q3.INSEE) %>% summarise(moy = mean(Q12))

# Import des couches géographiques (format géopackages) 
shp_idf <- st_read("data/com_idf.gpkg") # Les communes de la petite couronne
bercy <- st_read("data/gare_bercy.gpkg") # La localisation de la gare de Bercy

# Vérification 
plot(st_geometry(shp_idf))

# Jointure entre le fichier spatiale et la donnée atributaire 
joint <- left_join(shp_idf, trajet_bercy, by = c("INSEE_COM" = "Q3.INSEE")) %>%
  drop_na()

# Réalisation de la carte choroplèthe

# Prépare l'export de la carte 
mf_export(joint, filename = "export/trajet_moy_bercy.png", width = 600)

# Initie l'emprise sur le shapefile
mf_init(x = shp_idf)
# Changement graphique dans le thème de base
mf_theme("default", tab = FALSE)
# Affiche les communes en fond
mf_map(shp_idf, border = "white", lwd = 1, add = TRUE)
# Affiche l'information
mf_map(
  x = joint,
  var = "moy",
  type = "choro",
  breaks = c(0,10,20,30,45,60,90),
  pal = "Reds",
  border = "white",
  lwd = 0.01,
  leg_pos = "topleft",
  leg_title = "Temps moyen (min)",
  add = TRUE)

# Affiche la gare de Bercy
mf_map(bercy,
       add = TRUE)
# Affiche le texte de la gare de Bercy
mf_label(
  x = bercy, var = "nom",
  cex = 0.6, halo = FALSE,
  pos = 4,
  offset = 0.2,
)

# Layout (titre, crédits...)
mf_layout(
  title = "Temps de trajet moyen pour se rendre à la gare de Paris Bercy",
  arrow = FALSE,
  credits = paste0(
    "Sources: Enquête Parcours Voyageurs SNCF Gares & Connexions, 2021\n",
    "mapsf ",
    packageVersion("mapsf")
  )
)
# Ferme la fenêtre graphique pour permettre l'export
dev.off()

